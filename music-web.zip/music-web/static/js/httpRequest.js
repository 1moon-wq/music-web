//axios封装post请求form data
function axiosPostFormRequst(url,data) {
    let result = axios({
        method: 'post',
        url: url,
        data: data,
        transformRequest:[function(data){
            let ret = '';
            for(let i in data){
                ret += encodeURIComponent(i)+'='+encodeURIComponent(data[i])+"&";
            }
            return ret;
        }],
        headers:{
            'Content-Type':'application/x-www-form-urlencoded'
        }
    }).then(resp=> {
        return resp.data;
    }).catch(error=>{
        return "exception="+error;
    });
    return result;
}
function axiosPostMutRequst(url,data) {
    let result = axios({
        method: 'post',
        url: url,
        data: data,
        headers:{
            "Content-Type": "multipart/form-data;boundary=--------------------------055294747289664422992011"
        }
    }).then(resp=> {
        return resp.data;
    }).catch(error=>{
        return "exception="+error;
    });
    return result;
}

function axiosPostRequst(url,data) {
    let result = axios({
        method: 'post',
        headers: {"Authorization":"Bearer "+sessionStorage.getItem("token")},
        url: url,
        data: data,

    }).then(resp=> {
        return resp.data;
    }).catch(error=>{
        return "exception="+error;
    });
    return result;
}

//get请
function axiosGetRequst(url) {
    var result = axios({
        method: 'get',
        url: url,
        headers: {"Authorization":"Bearer "+sessionStorage.getItem("token")},
    }).then(function (resp) {
        return resp.data;
    }).catch(function (error) {
        return "exception=" + error;
    });
    return result;
}